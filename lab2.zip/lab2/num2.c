#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
 
 
int main (int argc, char *argv[]) {
	int x=0, num_dl=1, num_kr=1, count_str=0, count_simb=0, len_dl=-2, len_kr=50000;
	string str=0; 
	char symb;
	if ((fp==fopen(argv[0],"r")) == NULL){
		printf("File does'nt exist")
	} 
 	else{
		fp=fopen(argv[0],"r");
		symb=fgetc(fp);
		while(symb!=EOF){
			while(symb!="\n"){
				str+=symb;
			}
			if(len_dl<str.size()){
				num_dl=count_str+1;
				len_dl=str.size();
			}
			if(len_kr>str.size()){
				num_kr=count_str+1;
				len_kr=str.size();
			}
		}

	}
	fclose(fp);
	return 0;
 
}

